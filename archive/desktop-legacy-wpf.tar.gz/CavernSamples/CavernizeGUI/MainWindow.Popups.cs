﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;

using Cavern.Channels;
using Cavern.Format;
using Cavern.Format.Common;
using Cavern.Virtualizer;
using Cavern.Waveforms;
using Cavern.WPF;
using Cavern.WPF.Consts;

using Cavernize.Logic.Models;
using Cavernize.Logic.Models.RenderTargets;
using Cavernize.Logic.Rendering;
using CavernizeGUI.CavernSettings;
using CavernizeGUI.Windows;
using CavernizeGUI.Resources;

namespace CavernizeGUI;

public partial class MainWindow {
    /// <summary>
    /// Store the post-render report here after renders.
    /// </summary>
    PostRenderReport report;

    /// <summary>
    /// Try to load a HRIR file and return true on success.
    /// If the file is invalid, an optional error message popup can be displayed.
    /// </summary>
    static bool TryLoadHRIR(bool popupOnError) {
        RIFFWaveReader file;
        try {
            file = new RIFFWaveReader(Settings.Default.hrirPath);
            file.ReadHeader();
        } catch (Exception e) {
            if (popupOnError) {
                Error(string.Format(language["IrErr"], e.Message));
            }
            return false;
        }
        VirtualizerFilter.Override(VirtualChannel.Parse(new MultichannelWaveform(file.ReadMultichannelAfterHeader()), file.SampleRate),
            file.SampleRate);
        return true;
    }

    /// <summary>
    /// Ask the user where to save the currently set up export. If the user cancels the operation, null is returned.
    /// </summary>
    string AskUserForExportPath() {
        SaveFileDialog dialog = new() {
            FileName = fileName.Text.Contains('.') ? fileName.Text[..fileName.Text.LastIndexOf('.')] : fileName.Text
        };
        if (Directory.Exists(Settings.Default.lastDirectory)) {
            dialog.InitialDirectory = Settings.Default.lastDirectory;
        }

        Codec codec = ((ExportFormat)audio.SelectedItem).Codec;
        dialog.Filter = MergeToContainer.GetPossibleContainers((CavernizeTrack)tracks.SelectedItem, codec, ffmpeg);
        return dialog.ShowDialog().Value ? dialog.FileName : null;
    }

    /// <summary>
    /// Opens the upmixing settings.
    /// </summary>
    void OpenUpmixSetup(object _, RoutedEventArgs e) {
        UpmixingSetup setup = new(new DynamicUpmixingSettings(), Background, Resources);
        if (setup.ShowDialog().Value) {
            CavernizeGUI.Resources.UpmixingSettings.Default.Save();
        }
    }

    /// <summary>
    /// Load a set of HRTF impulses (HRIRs) for the Virtualizer.
    /// </summary>
    void LoadHRIR(object _, RoutedEventArgs e) {
        if (!hrir.IsChecked) {
            OpenFileDialog dialog = new() {
                Filter = language["FiltI"]
            };
            if (dialog.ShowDialog().Value) {
                Settings.Default.hrirPath = dialog.FileName;
                hrir.IsChecked = TryLoadHRIR(true);
            }
        } else {
            VirtualizerFilter.Reset();
            Settings.Default.hrirPath = string.Empty;
            hrir.IsChecked = false;
        }
    }

    /// <summary>
    /// Load a set of room correction filters to EQ the exported content.
    /// </summary>
    void LoadFilters(object _, RoutedEventArgs __) {
        if (filters.IsChecked) {
            filters.IsChecked = false;
            RenderingSettings.RoomCorrection = null;
            return;
        }

        OpenFileDialog dialog = new() {
            Filter = language["FiltF"]
        };
        if (Directory.Exists(Settings.Default.lastOutputFilters)) {
            dialog.InitialDirectory = Settings.Default.lastOutputFilters;
        }
        if (!dialog.ShowDialog().Value) {
            return;
        }

        try {
            this.LoadRoomCorrection(dialog.FileName);
            Settings.Default.lastOutputFilters = Path.GetDirectoryName(dialog.FileName);
            filters.IsChecked = true;
        } catch (Exception e) {
            Error(e.Message);
            filters.IsChecked = false;
            RenderingSettings.RoomCorrection = null;
        }
    }

    /// <summary>
    /// Show the post-render report in a popup.
    /// </summary>
    void ShowMetadata(object _, RoutedEventArgs e) {
        if (tracks.SelectedItem is not CavernizeTrack track) {
            Error(language["CMeET"]);
            return;
        }

        ReadableMetadata metadata = track.GetMetadata();
        if (metadata == null) {
            Error(language["CMeUT"]);
            return;
        }

        new CodecMetadata(metadata) {
            Title = language["CMetT"]
        }.Show();
    }

    /// <summary>
    /// Show the post-render report in a popup.
    /// </summary>
    void ShowPostRenderReport(object _, RoutedEventArgs e) => MessageBox.Show(report.Report, language["PReRe"]);

    /// <summary>
    /// Shows a popup about what channel should be wired to which output.
    /// </summary>
    void DisplayWiring(object _, RoutedEventArgs e) {
        ReferenceChannel[] channels = RenderTarget.GetNameMappedChannels();
        if (RenderTarget is DownmixedRenderTarget downmix) {
            channels.DisplayWiring(downmix.MatrixWirings);
        } else {
            channels.DisplayWiring();
        }
    }
}
